import{a as t}from"../chunks/entry.CIlXG8dE.js";export{t as start};
